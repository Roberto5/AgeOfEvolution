<?php
  class ev_Layout_Controller_Plugin_Layout extends Zend_Layout_Controller_Plugin_Layout
  {
    public function preDispatch(Zend_Controller_Request_Abstract $request){
      switch ($request->getModuleName()){
        case 's1':
          $this->_moduleChange('s1');
        }
      }

    protected function _moduleChange($moduleName){
      $basePath = dirname(dirname(dirname($this->getLayout()->getLayoutPath())));
      $this->getLayout()->setLayoutPath($basePath.DIRECTORY_SEPARATOR.$moduleName.'/views/layout');
      $this->getLayout()->setLayout($moduleName);
    }
  }

?>