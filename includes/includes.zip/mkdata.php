<?php
/**
 * costruisce il codice per il file data.php
 * genera le classi statiche con tutti i parametri fissati.
 * @todo aggiungere destrizione delle strutture
 * @todo per i magazzini si metterà in js una barra per il riempimento
 */
include("functions.php");

class storage1
{
    var $capacity = array(1000,1500,2500,4000,6000,8500,11500,15000,19000,23500,28500,34000,40000,46500,
        53500,61000,69000,77500,86500,96000,106000);
    var $cost =array();
    var $time = array();
    var $require = "null";
    var $multiple_at_level20 = "true";
    var $maxliv=array(20,20,20,20,20,20);
    var $content="\"capacit&aacute;: {0}<br/>al prossimo livello: [0]<br/>\"";
    var $Description=array("\"la capanna dello sciamano aumenta la capacit&agrave; di immagazzinamento della pietra.
<blockquote>La capanna dello sciamano custodisce le pietre preziose per la civilt&agrave; preistorica.</blockquote>\"");
    var $param=array("\"capacity\"");
    var $maxPop=array("1","1","1","1","1","1");
    function __construct()
    {
        for ($i = 0; $i < 20; $i++) {
            $this->cost[$i][0]=  $this->capacity[$i+1]*$i/100+50;
            $this->cost[$i][1]=  0;
            $this->cost[$i][2]=  $this->capacity[$i+1]*$i/100+50;
            $this->cost[$i][3]=  $i+1;
            $tot = $this->cost[$i][0] + $this->cost[$i][1] + $this->cost[$i][2];
            $this->time[$i] = intval($tot * 60 / 100);
        }
    }
}
class storage2
{
    var $capacity = array(1000,1500,2500,4000,6000,8500,11500,15000,19000,23500,28500,34000,40000,46500,
        53500,61000,69000,77500,86500,96000,106000);
    var $cost =array();
    var $time = array();
    var $require = "null";
    var $multiple_at_level20 = "true";
    var $maxliv=array(20,20,20,20,20,20);
    var $content="\"capacit&agrave;: {0}<br/>al prossimo livello: [0]<br/>\"";
    var $Description=array("\"la dispensa aumenta la capacit&agrave; di immagazzinamento del legno e del cibo.
<blockquote>nella dispensa viene conservato il cibo, e la legna raccolta durante il giorno</blockquote>\"");
    var $param=array("\"capacity\"");
    var $maxPop=array("1","1","1","1","1","1");
    function __construct()
    {
        for ($i = 0; $i < 20; $i++) {
            $this->cost[$i][0]=  0;
            $this->cost[$i][1]=  0;
            $this->cost[$i][2]=  $this->capacity[$i+1]*$i/50+100;
            $this->cost[$i][3]=  $i+1;
            $tot = $this->cost[$i][0] + $this->cost[$i][1] + $this->cost[$i][2];
            $this->time[$i] = intval($tot * 60 / 100);
        }
    }
}
class main
{
    var $rid = array(2,1,0.92,0.84,0.78,0.71,0.66,0.6,0.55,0.51,0.47,0.43,0.39,0.36,0.33,0.31,0.28,0.26,
        0.24,0.22,0.2);
    var $cost = array();
    var $time = array();
    var $require = "null";
    var $multiple_at_level20 = "false";
    var $maxliv=array(20,20,20,20,20,20);
    var $content="\"fattore di riduzione: {0}<br/>al prossimo livello: [0]<br/>\"";
    var $Description=array("\"il focolare aumenta la velocit&agrave; di costruzione delle strutture.
<blockquote>davanti il focolare si riunisce tutta la trib&ugrave; per decidere il da-farsi</blockquote>\"");
    var $param=array("\"rid\"");
    var $maxPop=array("1","10","20","40","80","160");
    function __construct()
    {
        for ($i = 0; $i < 20; $i++) {
            $rid = 2 - $this->rid[$i + 1];
            $this->cost[$i] = array(intval($rid * 200),intval($rid * 200),intval($rid * 300),$i+1);
            $tot = $this->cost[$i][0] + $this->cost[$i][1] + $this->cost[$i][2];
            $this->time[$i] = intval($tot * 60 / 100);
        }
    }
}
class prod1
{
    var $prod = array(10,12,16,20,25,32,40,50,64,80,100,120,160,200,250,320,400,500,640,800,1000);
    var $cost = array();
    var $time = array();
    var $require = "null";
    var $multiple_at_level20 = "false";
    var $maxliv=array(20,20,20,20,20,20);
    var $content="\"produzione {0}<br/>al prossimo livello: [0]<br/>\"";
    var $Description=array("\"la cava di pietra produce pietra
<blockquote>nella cava si trovano le pietre preziose per la trib&ugrave;, pietre ornamentali, oppure pietre da taglio</blockquote>\"");
    var $param=array("\"prod\"");
    var $maxPop=array("1","10","20","40","80","160");
    function __construct()
    {
        for ($i = 0; $i < 20; $i++) {
            $this->cost[$i] = array($this->prod[$i] * 5,$this->prod[$i] * 10,$this->prod[$i] * 10,$i+1);
            $tot = $this->cost[$i][0] + $this->cost[$i][1] + $this->cost[$i][2];
            $this->time[$i] = intval($tot * 60 / 100);
        }
    }
}
class prod2
{
    var $prod = array(10,12,16,20,25,32,40,50,64,80,100,120,160,200,250,320,400,500,640,800,1000);
    var $cost = array();
    var $time = array();
    var $require = "null";
    var $multiple_at_level20 = "false";
    var $maxliv=array(20,20,20,20,20,20);
    var $content="\"produzione {0}<br/>al prossimo livello: [0]<br/>\"";
    var $Description=array("\"l'allevamento produce cibo
<blockquote>l'allevamento e la caccia sono i lavori essenziali per la sopravvivenza della trib&ugrave;.</blockquote>\"");
    var $param=array("\"prod\"");
    var $maxPop=array("1","10","20","40","80","160");
    function __construct()
    {
        for ($i = 0; $i < 20; $i++) {
            $this->cost[$i] = array($this->prod[$i] * 10,$this->prod[$i] * 5,$this->prod[$i] * 10,$i+1);
            $tot = $this->cost[$i][0] + $this->cost[$i][1] + $this->cost[$i][2];
            $this->time[$i] = intval($tot * 60 / 100);
        }
    }
}
class prod3
{
    var $prod = array(10,12,16,20,25,32,40,50,64,80,100,120,160,200,250,320,400,500,640,800,1000);
    var $cost = array();
    var $time = array();
    var $require = "null";
    var $multiple_at_level20 = "false";
    var $maxliv=array(20,20,20,20,20,20);
    var $content="\"produzione {0}<br/>al prossimo livello: [0]<br/>\"";
    var $Description=array("\"la segheria produce legno
<blockquote>la segheria porta legno alla trib&ugrave; per la costruzione delle strutture</blockquote>\"");
    var $param=array("\"prod\"");
    var $maxPop=array("1","10","20","40","80","160");
    function __construct()
    {
        for ($i = 0; $i < 20; $i++) {
            $this->cost[$i] = array($this->prod[$i] * 10,$this->prod[$i] * 10,$this->prod[$i] * 5,$i+1);
            $tot = $this->cost[$i][0] + $this->cost[$i][1] + $this->cost[$i][2];
            $this->time[$i] = intval($tot * 60 / 100);
        }
    }
}
class house
{
    var $capacity = array(100,150,250,400,600,850,1150,1500,1900,2350,2850,3400,4000,4650,5350,6100,
        6900,7750,8650,9600,10600);
    var $cost = array(array(0,100,0,0),array(0,150,0,0),array(0,250,0,0),array(0,400,0,0),array(0,600,0,
        0),array(0,850,0,0),array(0,1150,0,0),array(0,1500,0,0),array(0,1900,0,0),array(0,2350,0,0),array(0,
        2850,0,0),array(0,3400,0,0),array(0,4650,0,0),array(0,535,0,0),array(0,6100,0,0),array(0,6900,0,0),
        array(0,7750,0,0),array(0,8650,0,0),array(0,9600,0,0),array(0,10600,0,0));
    var $time = array();
    var $require = "null";
    var $multiple_at_level20 = "false";
    var $maxliv=array(6,20,20,20,20,20);
    var $content="\"alloggi disponibili {0}<br/>al prossimo livello: [0]<br/>\"";
    var $Description=array("\"le palafitte aumentano la capacit&agrave; di immagazzinamento della popolazione<br/>
<blockquote>quando le caverne diventarono strette per contenere tutta la trib&ugrave;, si decise di costruire case che fossero al sicuro dai predatori, cosi costruirono le loro case sull'acqua, le palafitte.</blockquote>\"");
    var $param=array("\"capacity\"");
    var $maxPop=array("1","1","1","1","1","1");
    function __construct()
    {
        for ($i = 0; $i < 20; $i++) {
            $this->content=__($this->content);
            $this->Description=__($this->Description);
            $this->cost[$i][0]=  0;
            $this->cost[$i][1]=  0;
            $this->cost[$i][2]= (int) $this->capacity[$i+1]*$i/50+100;
            $this->cost[$i][3]=  $i;
            $tot = $this->cost[$i][0] + $this->cost[$i][1] + $this->cost[$i][2];
            $this->time[$i] = intval($tot * 60 / 100);
        }
    }
}
class market
{
    var $cost =array();
    var $time = array();
    var $require = array(array('type'=>'2','liv'=>'1'),array('type'=>'3','liv'=>'1'),'age'=>'1');
    var $multiple_at_level20 = "true";
    var $maxliv=array(20,20,20,20,20,20);
    var $content='\' <script type="text/javascript" >getMarketForm(0);</script>
<p id="market" ></p> \'';
    var $Description=array("\"tenda del mercante permette di scambiare risorse con gli altri villaggi\"");
    var $param="null";
    var $maxPop=array("1","10","20","30","40","50");
    function __construct()
    {
        for ($i = 0; $i < 20; $i++) {
            $this->cost[$i][0]= intval( $i*$i/100+150);
            $this->cost[$i][1]=  intval($i*$i/100+100);
            $this->cost[$i][2]=  intval($i*$i/100+250);
            $this->cost[$i][3]=  $i+1;
            $tot = $this->cost[$i][0] + $this->cost[$i][1] + $this->cost[$i][2];
            $this->time[$i] = intval($tot * 60 / 100);
        }
    }
}
class barrack {
    var $cost =array();
    var $time = array();
    var $rid = array(2,1,0.92,0.84,0.78,0.71,0.66,0.6,0.55,0.51,0.47,0.43,0.39,0.36,0.33,0.31,0.28,0.26,
        0.24,0.22,0.2);
    var $require = array(array('type'=>'1','liv'=>'5'),array('type'=>'5','liv'=>'3'),'age'=>'1');
    var $multiple_at_level20 = "false";
    var $maxliv=array(20,20,20,20,20,20);
    var $content='\' <script type="text/javascript" >getQueuetroops(1);</script>
<p id="barrack" ></p> \'';
    var $Description=array("\"addestra truppe\"");
    var $param="null";
    var $maxPop=array("2","10","20","30","40","50");
    function __construct()
    {
        for ($i = 0; $i < 20; $i++) {
            $this->cost[$i][0]= intval( $i*$i/100+250);
            $this->cost[$i][1]=  intval($i*$i/100+300);
            $this->cost[$i][2]=  intval($i*$i/100+100);
            $this->cost[$i][3]=  $i+1;
            $tot = $this->cost[$i][0] + $this->cost[$i][1] + $this->cost[$i][2];
            $this->time[$i] = intval($tot * 60 / 100);
        }
    }
}

$s1 = new storage1();
$s2 = new storage2();
$p1= new prod1();
$p2= new prod2();
$p3= new prod3();
$m= new main();
$h= new house();
$ma= new market();
$ba=new barrack();

echo "&lt;?php<br/>";
getcode($s1);
getcode($s2);
getcode($p1);
getcode($p2);
getcode($p3);
getcode($m);
getcode($h);
getcode($ma);
getcode($ba);
echo "?&gt;";

function getcode($obj)
{
    $text=print_r($obj,true);
    $i=  strpos($text, " ");
    $obj=  substr($text, 0,$i);
    $text=substr($text, $i);
    echo "class ".$obj."<br/>{<br/>";
    while (strlen($text)>3)
    {
        $i=  strpos($text, "[");
        $j=  strpos($text, "]");
        $propiety=substr($text, $i+1, $j-$i-1);
        echo "static $".$propiety."=";
        $i=  strpos($text, "=>")+3;
        $text=substr($text, $i);
        if (substr($text, 0, 5)=="Array") {
            $array=getArray($text);
            $text=$array['text'];
            $array=str_replace("[", ",[", $array['array']);
            $array=str_replace("[", "'", $array);
            $array=str_replace("]", "'", $array);
            $array=str_replace(",'0'", "'0'", $array);//(\n
            $array=htmlentities($array);
            echo $array.";<br/>";
        }
        else {
            $i=strpos($text, "[");
            if ($i) $dat=substr($text, 0, $i);
            else $i=strpos($text,")");
            $dat=substr($text, 0, $i);
            $dat=htmlentities($dat);
            echo $dat.";<br/>";
            $text=substr($text, $i);
        }
}
echo ' &nbsp;function getContent($liv)<br/>
 &nbsp;{<br/>
 &nbsp; &nbsp;$text='.$obj.'::$content;<br/>
 &nbsp; &nbsp;foreach ('.$obj.'::$param as $k => $v){<br/>
 &nbsp; &nbsp; &nbsp;$r='.$obj.'::$$v;<br/>
 &nbsp; &nbsp; &nbsp;$text= str_replace("{".$k."}",$r[$liv],$text);<br/>
 &nbsp; &nbsp; &nbsp;$text= str_replace("[".$k."]",$r[$liv+1],$text);<br/>
 &nbsp; &nbsp;}<br/>
 &nbsp; &nbsp;return $text;<br/>
 &nbsp;}<br/>
}<br/>';
}


function getArray($testo)
{
    
    $j=strpos ($testo, ")");
    $i=strpos($testo, "=> Array");
    //echo "j '".$j."' i '".$i."' <br/> ";
    $end="";
    if (($j>$i)&&($i)) {
        $j=strpos ($testo, ")\n\n        )");
        $end=")";
    }
    //echo "j '".$j."'";
    $array['array']=substr($testo, 0, $j+1).$end;
    $array['text']=substr($testo, $j);
    return $array;
}
?>
