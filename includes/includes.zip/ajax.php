<?php



$action = (isset($_POST['action']) && !empty($_POST['action'])) ? $_POST['action'] : '';
switch ($action) {
    default:
        break;
    case 'reg':
        
        break;
    case 'SearchCiv':
        
        break;
    case 'subscrive':
        $id = (int) $_POST['id'];
        $risposta = $fw->civ->subscrive($id, false, false);
        echo json_encode($risposta);
        break;
    
        break;
    case 'sendMail' :
        
        break;
    case 'marketForm' : 
		include(PATH."includes/ajax/market.php");
    break;
    case "marketTime": $cord = $fw->db->sql_toarray("SELECT `x`,`y` FROM `" . MAP_TABLE. "` WHERE `id`='" . intval($_POST['id']) . "'");
        $time = $fw->getTime($cord, array('x' => $fw->civ->village->x, 'y' => $fw->civ->village->y), mercants::$speed[$fw->civ->getAge()]);
        echo "Arrivo in " . timeStampToString($time);
        break;
    case "getVettorVillage":$bool=true;
        $coord=array();
        foreach ($_POST as $key => $value) {
            if (substr($key, 0, 1)=='x') {
                $ind=substr($key, 1);
                $coord[$ind]['x']=$value;
            }
            if (substr($key, 0, 1)=='y') {
                $ind=substr($key, 1);
                $coord[$ind]['y']=$value;
            }
            
        }
        debug("coord", $coord, "ajax", 298, $bool);
        debug("post", $_POST, "ajax", 298, $bool);
        $coords=array();
        $t=0;
        foreach ($coord as $key => $value) {
            $coords[]="(`x`='".$coord[$key]['x']."' AND `y`='".$coord[$key]['y']."')";
            $t++;
        }
        debug("coords", $coords, "ajax", 304, $bool);
        $cond=implode(" OR ", $coords);
        debug("cond", $cond, "ajax", 306,$bool);
        $r=$fw->db->sql_query("SELECT `" . MAP_TABLE. "`.*, (SELECT `username` FROM `" . USERS_TABLE . "` WHERE `" . USERS_TABLE . "`.`ID` = (SELECT `user_id` FROM `" . RELATION_USER_CIV_TABLE . "` WHERE `" . RELATION_USER_CIV_TABLE . "`.`civ_id` = `" . MAP_TABLE. "`.`civ_id` LIMIT 1) LIMIT 1) AS `player`, (SELECT `nome` FROM `" . ALLY_TABLE . "` WHERE `" . ALLY_TABLE . "`.`id` = (SELECT `civ_ally` FROM `" . CIV_TABLE . "` WHERE `" . CIV_TABLE . "`.`civ_id` = `" . MAP_TABLE. "`.`civ_id` LIMIT 1) LIMIT 1) AS `ally` FROM `" . MAP_TABLE. "` WHERE ".$cond);
        $i=0;
        while ($temp=$fw->db->sql_fetchrow($r)) {
            if ($temp) $villages[$i]=$temp;
		$villages[$i]['type']=$fw->map->getZone($villages[$j]['x'], $villages[$j]['y']);
                $ctr[$i]=$villages[$i]['x']."_".$villages[$i]['y'];
                $i++;
        }
        debug("vilages", $villages, "ajax", 315,$bool);
        for ($j= 0; $j<$t; $j++) {
            if ((!$ctr)||(!in_array($coord[$j]['x']."_".$coord[$j]['y'], $ctr))) {
                $villages[]=array(
                            "name" => __("Valle inabitata"),
                            "player" => "-",
                            "ally" => "-",
                            "x" => $coord[$j]['x'],
                            "y" => $coord[$j]['y'],
                            "type" => "-".$fw->map->getZone($coord[$j]['x'], $coord[$j]['y']),
                            "busy_pop" => "-");
            }
        }
        debug("vilages", $villages, "ajax", 328,$bool);
        echo json_encode($villages);
        break;
    case "formBarrack":
        include(PATH."includes/ajax/barrack.php");
        break;
    case "avvisi":
        $id = (int) $_POST['id'];
        $fw->db->sql_query("INSERT INTO `" . ALERTS_READ . "` SET `user`='" . $fw->user->data->ID . "' , `id`='" . $id . "'");
        echo json_encode(true);
        break;
	case "change_god":
	if ((is_numeric($_POST['master_id'])) && ($_POST['master_id']>0) && ($_POST['master_id']<=4)) {
		if ($fw->civ->option->get("change_god")=='1') {
			$fw->db->sql_query("UPDATE `".CIV_TABLE."` SET `master` = '".$_POST['master_id']."'");
			$fw->civ->option->del("change_god");
			$fw->civ->option->set("have_god","1");
			echo json_encode(__("Dio scelto correttamente"));
		}else{
			echo json_encode(__("Non puoi cambiare dio"));
		}
	}else{
		echo json_encode(__("Errore, id del dio non corretto"));
	}
	break;
    case 'getTime' :
       $x=(int)$_POST['x'];
       $y=(int)$_POST['y'];
       $risposta=$fw->db->sql_toarray("SELECT `civ_name`,`name`,
       (IF (EXISTS (
            SELECT `name` FROM `".ALLY_TABLE."` WHERE `id`=`".CIV_TABLE."`.`civ_ally` LIMIT 1
           ) > 0,
          ( SELECT `name` FROM `".ALLY_TABLE."` WHERE `id`=`".CIV_TABLE."`.`civ_ally` LIMIT 1) , '-')
) as `ally`  FROM `".CIV_TABLE."`,`".VILLAGE_TABLE."` WHERE `x`='$x' AND `y`='$y' AND `".VILLAGE_TABLE."`.`civ_id`=`".CIV_TABLE."`.`civ_id`");
       if (!$risposta) $risposta=array('name'=>__('valle inabitata'),'civ_name'=>'-','ally'=>'-');
       echo json_encode($risposta);
   break;
    default : echo "chiamata ajax non supportata";
}
?>
