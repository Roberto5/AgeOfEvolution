<?php
$villages = null;
$list = $fw->civ->village_list;
for ($i = 0; $list[$i]; $i++)
	if ($list[$i]['id'] != $fw->civ->getCurrentVillage())
		$villages.='<option value="' . $list[$i]['id'] . '">' . $list[$i]['name'] . '</option>';
$pos = $fw->civ->building->getBildForType(MARKET);
$liv = $fw->civ->building->getLiv($pos);
$disp = $liv - $fw->civ->getMercantBusy();
$token = md5(auth());
$fw->session->set("tokenM", $token);
$travel = $fw->civ->getMercantsTravel();
$div_mercant = '
<table border="1">
<tr>
<tr><td>' . __('mittente') . '</td>
	<td>' . __('destinatario') . '</td>
	<td>' . __('risorse') . '</td>
	<td>' . __('arrivo') . '</td></tr>';
for ($i = 0; $travel['out'][$i]; $i++) {
	$p = unserialize($travel['out'][$i]['params']);
	$des = '<a href="profile.php?t=village&id=' . $p['destinatario'] . '">' . $fw->civ->getVillageName($p['destinatario']) . '</a>';
	$mit = '<a href="profile.php?t=village&id=' . $p['mittente'] . '">' . $fw->civ->getVillageName($p['mittente']) . '</a>';
	$div_mercant.='<tr><td>' . $mit . '</td>
		<td>' . $des . '</td><td>';
	for ($j = 0; $j < 3; $j++)
		$div_mercant.=$p['res'][$j] . ' ' . $fw->template->getImageResource($j, $fw->civ->getAge()) . ' &nbsp &nbsp ';
	$count = $travel['out'][$i]['time'] - mktime();
	/**
	 * IMPORTANTE! la prossima istruzione serve per evitare di bloccare
	 * il browser in un continuo ricaricamento se l'event procesor non
	 * ha processato l'evento.
	 */
	if ($count <= 0)
		$count = "00:00:0?";
	$div_mercant.='</td>
		<td><span class="countDown">' . $count . '</span></td></tr>';
}
$div_mercant.='</tr>
</table>';
$div_mercant = $fw->template->spoiler($div_mercant, false, __("mercanti in arrivo e in uscita"), __("mercanti in arrivo e in uscita")) . "<br />";
$spoiler = '
<table border="1">
<tr>
<tr><td>' . __('mittente') . '</td>
	<td>' . __('destinatario') . '</td>
	<td>' . __('risorse') . '</td>
	<td>' . __('arrivo') . '</td></tr>';
for ($i = 0; $travel['in'][$i]; $i++) {
	$p = unserialize($travel['in'][$i]['params']);
	$des = '<a href="profile.php?t=village&id=' . $p['destinatario'] . '">' . $fw->civ->getVillageName($p['destinatario']) . '</a>';
	$mit = '<a href="profile.php?t=village&id=' . $p['mittente'] . '">' . $fw->civ->getVillageName($p['mittente']) . '</a>';
	$spoiler.='<tr><td>' . $mit . '</td>
		<td>' . $des . '</td><td>';
	for ($j = 0; $j < 3; $j++)
		$spoiler.=$p['res'][$j] . ' ' . $fw->template->getImageResource($j, $fw->civ->getAge()) . ' &nbsp &nbsp ';
	$count = $travel['in'][$i]['time'] - mktime();
	/**
	 * IMPORTANTE! la prossima istruzione serve per evitare di bloccare
	 * il browser in un continuo ricaricamento se l'event procesor non
	 * ha processato l'evento.
	 */
	if ($count <= 0)
		$count = "00:00:0?";
	$spoiler.='</td>
		<td><span class="countDown">' . $count . '</span></td></tr>';
}
//cerco le offerte.
$offer1 = $fw->db->sql_totable("SELECT *,`civ_name` FROM `" . OFFER_TABLE . "`,`" . CIV_TABLE . "` WHERE `type`='1' AND `" . CIV_TABLE . "`.`civ_id`=`" . OFFER_TABLE . "`.`civ_id` ORDER BY `rapport` LIMIT 10");
$offer2 = $fw->db->sql_totable("SELECT *,`civ_name` FROM `" . OFFER_TABLE . "`,`" . CIV_TABLE . "` WHERE `type`='2' AND `" . CIV_TABLE . "`.`civ_id`=`" . OFFER_TABLE . "`.`civ_id` ORDER BY `rapport` LIMIT 10");
$of1 = '<table>
	<tr>
	<td>' . __("civiltà") . '</td>
	<td>' . __("risorse") . '</td>
	<td>' . __("costo") . '</td>
	<td></td>
	</tr>';
for ($i = 0; $offer1[$i]; $i++)
	$of1.='<tr>
		<td>' . $offer1[$i]['civ_name'] . '</td>
		<td>' . $offer1[$i]['resource'] . ' ' . $fw->template->getImageResource(1, $fw->civ->getAge()) . '</td>
		<td>' . $offer1[$i]['rapport'] . '</td>
		<td><a href="send.php?a=buy&id=' . $offer1[$i]['id'] . '&tokenM=' . $token . '">' . __("compra") . '</a></td>
		</tr>';
$of1.='</table>';
$of2 = '<table>
	<tr>
	<td>' . __("civiltà") . '</td>
	<td>' . __("risorse") . '</td>
	<td>' . __("costo") . '</td>
	<td></td>
	</tr>';
for ($i = 0; $offer2[$i]; $i++)
	$of2.='<tr>
		<td>' . $offer2[$i]['civ_name'] . '</td>
		<td>' . $offer2[$i]['resource'] . ' ' . $fw->template->getImageResource(2, $fw->civ->getAge()) . '</td>
		<td>' . $offer2[$i]['rapport'] . '</td>
		<td><a href="send.php?a=buy&id=' . $offer2[$i]['id'] . '&tokenM=' . $token . '">' . __("compra") . '</a></td>
		</tr>';
$of2.='</table>';
$div_offer = $fw->template->spoiler($of1, false, __("compra " . $fw->template->getImageResource(1, $fw->civ->getAge())), __("compra " . $fw->template->getImageResource(1, $fw->civ->getAge())));
$div_offer.="<br />" . $fw->template->spoiler($of2, false, __("compra " . $fw->template->getImageResource(2, $fw->civ->getAge())), __("compra " . $fw->template->getImageResource(2, $fw->civ->getAge())));
$spoiler.='</tr>
</table>';
$div_mercant.=$fw->template->spoiler($spoiler, false, __("mercanti in ritorno"), __("mercanti in ritorno"));
$form = array('
<script type="text/javascript">resetinit();</script>
<div style="border: 1px solid; width: 400px;">
<span ><b>invia</b></span><span style="border-width: 1px 0px 1px 1px; border-style: solid;"><a style="text-decoration: none;" href="#buy" onclick="getMarketForm(1)">compra</a></span><span style="border-width: 1px 0px 1px 1px; border-style: solid;"><a style="text-decoration: none;" href="#sel" onclick="getMarketForm(2)">vendi</a></span><span style="border: 1px solid;"><a style="text-decoration: none;" href="#black" onclick="getMarketForm(3)">mercato nero</a></span>

<div style="height: 20px; font-size: 20px;"><span style="position: relative; left: 80%;">' . $disp . '/' . $liv . '</span></div>
' . $div_mercant . '
<div style="height: 20px;"></div>

<form name="market" action="send.php?a=send&tokenM=' . $token . '" method="POST">
<table>


<tr><td>
' . $fw->template->getImageResource(0, $fw->civ->getAge()) . '<input name="res1" value="0" size="9" onkeyup="controlnumber(this)" /><br />
' . $fw->template->getImageResource(1, $fw->civ->getAge()) . '<input name="res2" value="0" size="9" onkeyup="controlnumber(this)" /><br />
' . $fw->template->getImageResource(2, $fw->civ->getAge()) . '<input name="res3" value="0" size="9" onkeyup="controlnumber(this)" /><br />
</td>
<td width="50"></td>
<td>
<select name="village" onchange="getTimeM(this.value)">
<option value=""></option>
' . $villages . '
</select><br/>
<input name="x" value="0" size="2" maxlength="4" onkeyup="controlnumber(this)" onchange="document.market.village.selectedIndex=0" /> |
<input name="y" value="0" size="2" maxlength="4" onkeyup="controlnumber(this)" onchange="document.market.village.selectedIndex=0" /> <br />
<input type="submit" name="submit" value="invia" />
</td>
</tr></table>
</form>

<div id="time"></div>
</div>
', '
<div style="border: 1px solid; width: 400px;">
<span style="border-width: 0px 0px 1px; border-style: solid;"><a style="text-decoration: none;" href="#send" onclick="getMarketForm(0)">invia</a></span><span style="border-width: 1px 0px 0px 1px; border-style: solid;"><b>compra</b></span><span style="border-width: 1px 0px 1px 1px; border-style: solid;"><a style="text-decoration: none;" href="#sel" onclick="getMarketForm(2)">vendi</a></span><span style="border: 1px solid;"><a style="text-decoration: none;" href="#black" onclick="getMarketForm(3)">mercato nero</a></span>

<div style="height: 20px; font-size: 20px;"><span style="position: relative; left: 80%;">' . $disp . '/' . $liv . '</span></div>

' . $div_offer . '

</div>
', '
<div style="border: 1px solid; width: 400px;">
<span style="border-width: 0px 0px 1px; border-style: solid;"><a style="text-decoration: none;" href="#send" onclick="getMarketForm(0)">invia</a></span><span style="border-width: 1px 0px 1px 1px; border-style: solid;"><a style="text-decoration: none;" href="#buy" onclick="getMarketForm(1)">compra</a></span><span style="border-width: 1px 0px 0px 1px; border-style: solid;"><b>vendi</b></span><span style="border: 1px solid;"><a style="text-decoration: none;" href="#black" onclick="getMarketForm(3)">mercato nero</a></span>

<div style="height: 20px; font-size: 20px;"><span style="position: relative; left: 80%;">' . $disp . '/' . $liv . '</span></div>
<form name="sell" action="send.php?a=sell&tokenM=' . $token . '" method="POST">
<input onkeyup="controlnumber(this)" onchange="sellres()" name="res" value="0" size="9" />
<select name="type">
<option value="1">' . $fw->civ->getNameResource(1, $fw->civ->getAge()) . '</option>
<option value="2">' . $fw->civ->getNameResource(2, $fw->civ->getAge()) . '</option>
</select> <br />
<input onkeyup="controlnumber(this)" onchange="sellres()" name="rap" value="1" maxlength="4" size="1" />
<input type="submit" name="submit" value="' . __("vendi") . '" /></form>
<div id="view" style="height: 20px;"></div>
</div>
', '
<div style="border: 1px solid; width: 400px;">
<span style="border-width: 0px 0px 1px; border-style: solid;"><a style="text-decoration: none;" href="#send" onclick="getMarketForm(0)">invia</a></span><span style="border-width: 1px 0px 1px 1px; border-style: solid;"><a style="text-decoration: none;" href="#buy" onclick="getMarketForm(1)">compra</a></span><span style="border-width: 1px 0px 1px 1px; border-style: solid;"><a style="text-decoration: none;" href="#sel" onclick="getMarketForm(2)">vendi</a></span><span style="border-width: 1px 0px 0px 1px; border-style: solid;"><b>mercato nero</b></span>

<div style="height: 20px;"></div>

</div>');
$listv = null;
for ($i = 0; $list[$i]; $i++)
	$listv[$list[$i]['id']] = $list[$i];
echo json_encode(array('html' => $form[$_POST['sess']], 'list' => $listv));
?>