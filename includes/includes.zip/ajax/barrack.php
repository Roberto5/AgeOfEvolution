<?php

//$debug=true;
$disp = array();
for ($i = 0; $Troops_Array[$i]; $i++) {
    $bool = true;
    if ($Troops_Array[$i]::$age != $fw->civ->getAge())
        $bool = false;
    //@todo altri controlli
    if ($bool)
        $disp[] = $i;
}
//token
$token = md5(auth());
$fw->session->set("tokenT", $token);
echo '<div style="border: 1px solid black;">
	<span style="' . ($_POST['section'] == 1 ? "" : "border-width: 0px 0px 1px 0px; border-style: solid;" ) . '"><' . ($_POST['section'] == 2 ? 'a style="text-decoration: none;" href="javascript:getQueuetroops(1);"' : 'b') . '>' . __("addestra") . '</' . ($_POST['section'] == 2 ? "a" : "b") . '></span><span style="' . ($_POST['section'] == 1 ? "border-width: 0px 1px 1px 1px; border-style: solid;" : "border-width: 0px 0px 0px 1px; border-style: solid;" ) . '"><' . ($_POST['section'] == 1 ? 'a style="text-decoration: none;" href="javascript:getQueuetroops(2);"' : "b") . '>' . __("promuovi") . '</' . ($_POST['section'] == 1 ? "a" : "b") . '></span>
		<br/><br/><script type="text/javascript">resetinit();</script>
	<table class="troopers" style="margin-left: 10px;">
	<thead><td></td>
	<td>' . __("numero") . '</td>
	<td>' . __("durata") . '</td>
	<td>' . __("finito") . '</td></thead>';
for ($i = 0; $fw->civ->training[$i]; $i++) {
    $params = unserialize($fw->civ->training[$i]['params']);
    $dif = $fw->civ->training[$i]['time'] - mktime();
    if ($dif <= 0)
        $dif = "00:00:0?";
    global $NameTroops;
    echo '<tr><td>' . $fw->template->getImageTroopers($params['trooper_id']) . '</td>
		<td>' . $params['num'] . '</td>
		<td><span class="countDown">' . $dif . '</span> </td>
			<td>' . date("H:i:s", $fw->civ->training[$i]['time']) . '</td></tr>';
}
echo "</table><br/>";
if ($_POST['section'] == 1) {
    echo '<form action="training.php" method="post" name="modulo">
<input name="tokenT" type="hidden" value="' . $token . '" />';
    foreach ($disp as $key => $value) {
        echo '<div style="padding-left: 10px;"><span style="border: 1px solid black;padding: 8px 3px 8px 2px;">' . $fw->template->getImageTroopers($value) . ' &nbsp &nbsp ';
        $res = $Troops_Array[$value]::$cost;
        for ($i = 0; $i < 3; $i++) {
            echo $res[$i] . ' ' . $fw->template->getImageResource($i, $fw->civ->getAge()) . ' &nbsp &nbsp ';
        }
        $p = $fw->civ->building->getproperty($fw->civ->building->getBildForType(BARRACK));
        $tadd = intval($Troops_Array[$key]::$time * $p['rid']);
        echo $res[$i] . ' <image src="' . URLSITO . '/common/images/pop.gif" />
			' . timeStampToString($tadd) . ' ';
        //max con le risorse
        $max = $p['liv'] * $p['maxpop'];
        $temp = $max;
        for ($i = 0; $i < 3; $i++) {
            $reso = "resource_" . ($i + 1);
            if ($res[$i])
                $temp = intval($fw->civ->resource->$reso / $res[$i]);
            if ($temp < $max)
                $max = $temp;
        }
        $popl = $fw->civ->resource->pop - $fw->civ->resource->busy_pop;
        if ($popl > 0)
            $temp = intval($popl / $res[3]);
        else
            $max=0;
        if ($temp < $max)
            $max = $temp;
        echo'<input name="t' . $value . '" size="3" /><a onclick="document.modulo.t' . $value . '.value=' . $max . ';">(' . $max . ')</a></span></div><br/>';
    }
    echo '<input value="' . __('addestra') . '" type="submit" /></form>';
}
else {
    $troop = $fw->civ->troopers_now;
    debug("troop", $troop, "barack", 70, $debug);
    echo '<form action="training.php?a=promote" method="post" name="modulo">
        <input name="tokenT" type="hidden" value="' . $token . '" />';
    for ($i = 0; $troop[$i]; $i++) {
        if ($Troops_Array[$troop[$i]['trooper_id']]::$age < $fw->civ->getAge()) {
            echo '<div style="padding-left: 10px;">' . $fw->template->getImageTroopers($troop[$i]['trooper_id']) . '
               -> <select id="type" style="padding-left: 20px;background: #FFF url(common/images/troops/t' . $disp[0] . '.gif) no-repeat;" name="type' . $troop[$i]['trooper_id'] . '" onchange="changeimg(this.value)">';
            for ($j = 0; $disp[$j]; $j++) {
                echo '<option value="' . $disp[$j] . '" style="padding-left: 20px;background: #FFF url(common/images/troops/t' . $disp[$j] . '.gif) no-repeat;">' . $NameTroops[$disp[$j]] . '</option>';
            }
            $cost = $Troops_Array[$disp[0]]::$cost[0] +
                    $Troops_Array[$disp[0]]::$cost[1] +
                    $Troops_Array[$disp[0]]::$cost[2] -
                    $Troops_Array[$troop[$i]['trooper_id']]::$cost[0] -
                    $Troops_Array[$troop[$i]['trooper_id']]::$cost[1] -
                    $Troops_Array[$troop[$i]['trooper_id']]::$cost[2];
            //max con le risorse
            $max = $troop[$i]['numbers'];
            $temp = $max;
            if ($cost)
                $temp = intval($fw->civ->resource->resource_1 / $cost);
            if ($temp < $max)
                $max = $temp;

            $popl = $fw->civ->resource->pop - $fw->civ->resource->busy_pop;
            if (($popl > 0)&&($pop!=0))
                $temp = intval($popl / $pop);
            if ($temp < $max)
                $max = $temp;
            echo'</select>
                <input name="t' . $troop[$i]['trooper_id'] . '" size="3" /><a onclick="document.modulo.t' . $troop[$i]['trooper_id'] . '.value=' . $max . ';">(' . $max . ')</a>
                &nbsp; &nbsp; <span id="cost' . $troop[$i]['trooper_id'] . '">' . $cost . '</span> ' . $fw->template->getImageResource(0, $fw->civ->getAge()) . '
                </div>';
        }
    }
    echo '<input value="' . __('Promuovi') . '" type="submit" /></form>';
}
echo '</div>';
?>
